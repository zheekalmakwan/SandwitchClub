package com.udacity.sandwichclub;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.udacity.sandwichclub.Adapter.SandwitchAdapter;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    ListView sandwitchListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sandwitchListView = findViewById(R.id.sandwiches_listview);

        ArrayList<String> lines = new ArrayList<String>(Arrays.asList(getResources().getStringArray(R.array.sandwich_details)));
        SandwitchAdapter sandwitchAdapter = new SandwitchAdapter(this, lines);
        Log.d("hii", lines.get(0));
        sandwitchListView.setAdapter(sandwitchAdapter);
        Log.d("hi", lines.get(0));

        sandwitchListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                launchDetailActivity(position);
            }
        });
    }

    private void launchDetailActivity(int position) {
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra(DetailActivity.EXTRA_POSITION, position);
        startActivity(intent);
    }
}
