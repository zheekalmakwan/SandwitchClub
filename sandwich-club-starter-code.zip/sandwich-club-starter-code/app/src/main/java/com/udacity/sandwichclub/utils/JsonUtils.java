package com.udacity.sandwichclub.utils;

import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    public static Sandwich parseSandwichJson(String json) {
        Sandwich sandwich = null;
        try {

            JSONObject rootJsonObject = new JSONObject(json);

            JSONObject nameObject = rootJsonObject.getJSONObject("name");

            String mainName = nameObject.optString("mainName");

            String placeOfOrigin = rootJsonObject.optString("placeOfOrigin");

            String description = rootJsonObject.optString("description");

            String imageURL = rootJsonObject.optString("image");

            List<String> alsoKnownAsArray = new ArrayList<>();
            for (int i = 0; i < nameObject.getJSONArray("alsoKnownAs").length(); i++) {
                try {
                    alsoKnownAsArray.add(nameObject.getJSONArray("alsoKnownAs").getString(i));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            List<String> ingredientsArray = new ArrayList<>();
            for (int i = 0; i < rootJsonObject.getJSONArray("ingredients").length(); i++) {
                try {
                    ingredientsArray.add(rootJsonObject.getJSONArray("ingredients").getString(i));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            sandwich = new Sandwich(mainName, alsoKnownAsArray, placeOfOrigin, description, imageURL, ingredientsArray);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return sandwich;
    }
}
