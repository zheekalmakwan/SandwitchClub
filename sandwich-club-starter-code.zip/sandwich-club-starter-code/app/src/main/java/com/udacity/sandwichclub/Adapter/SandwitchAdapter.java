package com.udacity.sandwichclub.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.udacity.sandwichclub.R;
import com.udacity.sandwichclub.model.Sandwich;
import com.udacity.sandwichclub.utils.JsonUtils;

import java.util.ArrayList;

public class SandwitchAdapter extends ArrayAdapter<String> {
    private Context context;
    private int resource;
    ArrayList<String> objects;

    public SandwitchAdapter(@NonNull Context context, @NonNull ArrayList<String> objects) {
        super(context, R.layout.list_view_style, objects);
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        SandwitchViewHolder sandwitchViewHolder;
        View costumView = null;
        if (convertView == null) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            costumView = layoutInflater.inflate(R.layout.list_view_style, parent, false);
            sandwitchViewHolder = new SandwitchViewHolder();
            sandwitchViewHolder.sandwitchImage = costumView.findViewById(R.id.sandwitch_image);
            sandwitchViewHolder.sandwitchName = costumView.findViewById(R.id.sandwiches_name);
            costumView.setTag(sandwitchViewHolder);
        } else {
            sandwitchViewHolder = (SandwitchViewHolder) convertView.getTag();

        }
        String[] sandwiches = getContext().getResources().getStringArray(R.array.sandwich_details);
        String json = sandwiches[position];
        Sandwich sandwich = JsonUtils.parseSandwichJson(json);

        Picasso.get()
                .load(sandwich.getImage())
                .placeholder(R.mipmap.ic_launcher)
                .error(R.mipmap.ic_launcher)
                .into(sandwitchViewHolder.sandwitchImage);
        sandwitchViewHolder.sandwitchName.setText(sandwich.getMainName());

        return costumView;
    }

}

class SandwitchViewHolder {
    ImageView sandwitchImage;
    TextView sandwitchName;

}
